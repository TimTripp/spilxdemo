
public class SplixGame {

	public static void main(String[] args) {
		System.out.println("Created on 01/30/2018 for the purpose of CSC380 UNCW.");
		Player p1 = new Player("Tobby");
		System.out.println(p1.toString());
	}

}
